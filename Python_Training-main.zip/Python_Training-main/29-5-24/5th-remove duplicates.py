#remove duplicates from list
l=list(map(int,input().split()))
res=set(l)
print(res)