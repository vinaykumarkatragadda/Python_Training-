n=[1,6,3,89,4,7,0]
for i in n:
    n.remove(i)
print(n)

for i in range(6):
    print(i)
    i+=2