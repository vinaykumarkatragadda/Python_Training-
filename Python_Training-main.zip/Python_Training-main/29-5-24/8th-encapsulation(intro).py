''' wrapping up of data is encapsulation or ** meand of bundling instance variables and methods ub order to restrict access to
certain class members.**
to make a member protected we use single underscore'_' before and
for private we use double underscore '__' before and all the classes are public by default.'''    