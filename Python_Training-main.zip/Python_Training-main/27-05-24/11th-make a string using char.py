stringlist = ['h','e','l','l','o']
res="".join(stringlist)
print(res)