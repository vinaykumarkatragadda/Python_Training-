s1="hey hello"
s2="""hello the girl
beside is my girlfriend"""
s3="2020"
print(s2.splitlines()) #splitlines which divides the lines and give the output
n=input()
print("this is a",n,"num")
print("this is a {0} dem output".format(n)) #format
print(s1*2)#repetition
print(s3.isdigit())