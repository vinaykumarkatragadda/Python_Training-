#given an integer n , return the number of ways youncan write n as the sum of consecutive positive integers
#input : n=15
#output: 4
#explanation : 15= 8+7=4+5+6=1+2+3+4+5
