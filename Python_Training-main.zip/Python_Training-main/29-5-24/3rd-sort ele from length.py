#sort the elements based on their length
l=input().split()
print(l)
res= sorted(l,key=len)
print(res)
