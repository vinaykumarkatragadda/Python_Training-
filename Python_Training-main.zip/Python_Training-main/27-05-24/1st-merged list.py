#create 2 lists by taking input and merge the lists and print output of merged list by sorting
list1 = list(map(int,input().split()))
list2 = list(map(int,input().split()))
listr = list1+list2
print(sorted(listr))


    